import React, { useState, useEffect, useRef } from 'react';
import { VolumeUp, VolumeOff, Business, Wifi, Schedule } from '@mui/icons-material';
import configuracionPantallaService from '../services/configuracionPantallaService';
import mensajeInstitucionalService from '../services/mensajeInstitucionalService';

// Simulación de datos de turnos en tiempo real
const TURNOS_TIEMPO_REAL = [
    { id: 1, codigo: 'A001', sector: 'OBRAS PÚBLICAS', ventanilla: 1, estado: 'LLAMANDO', ciudadano: 'MARTINEZ, JUAN', timestamp: Date.now() },
    { id: 2, codigo: 'B023', sector: 'RENTAS', ventanilla: 2, estado: 'EN_ATENCION', ciudadano: 'GONZALEZ, MARIA', timestamp: Date.now() - 30000 },
    { id: 3, codigo: 'C015', sector: 'TRÁNSITO', ventanilla: 3, estado: 'EN_ATENCION', ciudadano: 'RODRIGUEZ, CARLOS', timestamp: Date.now() - 60000 },
    { id: 4, codigo: 'A002', sector: 'OBRAS PÚBLICAS', ventanilla: 1, estado: 'PENDIENTE', ciudadano: 'LOPEZ, ANA', timestamp: Date.now() - 90000 },
    { id: 5, codigo: 'B024', sector: 'RENTAS', ventanilla: 2, estado: 'PENDIENTE', ciudadano: 'FERNANDEZ, LUIS', timestamp: Date.now() - 120000 },
    { id: 6, codigo: 'D008', sector: 'MESA DE ENTRADAS', ventanilla: 4, estado: 'PENDIENTE', ciudadano: 'SILVA, ROSA', timestamp: Date.now() - 150000 },
    { id: 7, codigo: 'C016', sector: 'TRÁNSITO', ventanilla: 3, estado: 'PENDIENTE', ciudadano: 'MORALES, PEDRO', timestamp: Date.now() - 180000 },
    { id: 8, codigo: 'A003', sector: 'OBRAS PÚBLICAS', ventanilla: 1, estado: 'PENDIENTE', ciudadano: 'GUTIERREZ, ELENA', timestamp: Date.now() - 210000 }
];

// Mensajes multimedia de prueba
const MENSAJES_MULTIMEDIA = [
    {
        id: 1,
        tipo: 'TEXTO',
        titulo: 'Horarios de Atención',
        contenido: 'Lunes a Viernes de 8:00 a 16:00 hs.\nSábados de 9:00 a 12:00 hs.\n\nRecuerde traer DNI y documentación completa.',
        activo: true,
        orden: 1
    },
    {
        id: 2,
        tipo: 'IMAGEN',
        titulo: 'Campaña de Vacunación Antigripal',
        contenido: 'Vacúnate contra la gripe estacional. Centro de Salud Municipal - Turnos disponibles.',
        rutaArchivo: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=800&h=600&fit=crop&crop=center',
        activo: true,
        orden: 2
    },
    {
        id: 3,
        tipo: 'VIDEO',
        titulo: 'Programa de Obras Públicas 2024',
        contenido: 'Conoce las nuevas obras que se están realizando en nuestra ciudad.',
        rutaArchivo: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        activo: true,
        orden: 3
    },
    {
        id: 4,
        tipo: 'IMAGEN',
        titulo: 'Actividades Culturales',
        contenido: 'Inscripciones abiertas para talleres de arte y cultura. Centro Cultural Municipal.',
        rutaArchivo: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=800&h=600&fit=crop&crop=center',
        activo: true,
        orden: 4
    },
    {
        id: 5,
        tipo: 'TEXTO',
        titulo: 'Descuento en Tasas Municipales',
        contenido: '15% de descuento pagando antes del 30 de septiembre.\n\nPago online disponible en www.sanantonio.gob.ar\n\nTambién en ventanillas de lunes a viernes.',
        activo: true,
        orden: 5
    }
];

// Configuración por defecto
const CONFIGURACION_DEFAULT = {
    id: 1,
    nombre: 'Pantalla Principal',
    textoEncabezado: 'SISTEMA DE TURNOS - MUNICIPALIDAD DE SAN ANTONIO',
    temaColor: 'blue',
    mostrarLogo: true,
    rutaLogo: null,
    sonidoActivo: true,
    volumenSonido: 75,
    archivoSonido: 'turno-llamado.mp3',
    animacionesActivas: true,
    tiempoMensaje: 8,
    tiempoTurno: 15
};

const PantallaTurnosProfesional = () => {
    // Estados principales
    const [configuracion, setConfiguracion] = useState(CONFIGURACION_DEFAULT);
    const [mensajes, setMensajes] = useState(MENSAJES_MULTIMEDIA);
    const [turnos, setTurnos] = useState(TURNOS_TIEMPO_REAL);
    const [vistaActual, setVistaActual] = useState('turnos'); // 'turnos' o 'mensaje'
    const [mensajeActual, setMensajeActual] = useState(0);
    const [horaActual, setHoraActual] = useState(new Date());
    const [turnoLlamando, setTurnoLlamando] = useState(null);
    const [sonidoHabilitado, setSonidoHabilitado] = useState(true);
    const [loading, setLoading] = useState(true);
    const [conexionEstado, setConexionEstado] = useState('conectado');

    const audioRef = useRef(null);
    const videoRef = useRef(null);
    const intervalVistaRef = useRef(null);
    const intervalTurnosRef = useRef(null);
    const intervalConexionRef = useRef(null);

    // Cargar configuración inicial
    useEffect(() => {
        const cargarDatos = async () => {
            try {
                setLoading(true);

                // Simular carga de datos
                await new Promise(resolve => setTimeout(resolve, 2000));

                // En producción, cargar desde la API
                // const config = await configuracionPantallaService.obtenerConfiguracionActiva();
                // const msgs = await mensajeInstitucionalService.obtenerMensajesVigentes();

                setLoading(false);
            } catch (error) {
                console.error('Error cargando datos:', error);
                setLoading(false);
            }
        };

        cargarDatos();
    }, []);

    // Actualizar hora cada segundo
    useEffect(() => {
        const timer = setInterval(() => {
            setHoraActual(new Date());
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    // Simular conexión en tiempo real
    useEffect(() => {
        intervalConexionRef.current = setInterval(() => {
            // Simular cambios de estado de turnos
            setTurnos(prev => prev.map(turno => {
                if (Math.random() < 0.05) { // 5% probabilidad de cambio
                    if (turno.estado === 'PENDIENTE' && Math.random() < 0.3) {
                        return { ...turno, estado: 'LLAMANDO' };
                    } else if (turno.estado === 'LLAMANDO') {
                        return { ...turno, estado: 'EN_ATENCION' };
                    }
                }
                return turno;
            }));
        }, 3000); // Cada 3 segundos

        return () => {
            if (intervalConexionRef.current) {
                clearInterval(intervalConexionRef.current);
            }
        };
    }, []);

    // Alternancia entre vistas
    useEffect(() => {
        if (mensajes.length > 0 && !loading) {
            intervalVistaRef.current = setInterval(() => {
                setVistaActual(prev => {
                    if (prev === 'turnos') {
                        setMensajeActual(current => (current + 1) % mensajes.length);
                        return 'mensaje';
                    } else {
                        return 'turnos';
                    }
                });
            }, configuracion.tiempoMensaje * 1000);

            return () => {
                if (intervalVistaRef.current) {
                    clearInterval(intervalVistaRef.current);
                }
            };
        }
    }, [mensajes, configuracion.tiempoMensaje, loading]);

    // Detectar turnos llamando y reproducir sonido
    useEffect(() => {
        const turnosSiendoLlamados = turnos.filter(t => t.estado === 'LLAMANDO');

        if (turnosSiendoLlamados.length > 0) {
            const primerTurno = turnosSiendoLlamados[0];

            if (!turnoLlamando || turnoLlamando.id !== primerTurno.id) {
                setTurnoLlamando(primerTurno);
                setVistaActual('turnos'); // Forzar vista de turnos cuando hay llamada

                // Reproducir sonido
                if (configuracion.sonidoActivo && sonidoHabilitado && audioRef.current) {
                    audioRef.current.volume = configuracion.volumenSonido / 100;
                    audioRef.current.play().catch(console.warn);
                }
            }
        } else {
            setTurnoLlamando(null);
        }
    }, [turnos, configuracion.sonidoActivo, configuracion.volumenSonido, sonidoHabilitado]);

    const obtenerClasesTema = () => {
        const temas = {
            'blue': 'bg-gradient-to-br from-blue-900 via-blue-800 to-slate-900',
            'green': 'bg-gradient-to-br from-green-900 via-green-800 to-slate-900',
            'red': 'bg-gradient-to-br from-red-900 via-red-800 to-slate-900',
            'purple': 'bg-gradient-to-br from-purple-900 via-purple-800 to-slate-900',
            'dark': 'bg-gradient-to-br from-gray-900 via-gray-800 to-black',
        };
        return temas[configuracion.temaColor] || temas['blue'];
    };

    const obtenerEstadoTurno = (estado) => {
        switch (estado) {
            case 'LLAMANDO':
                return {
                    clase: 'bg-red-500 text-white animate-pulse shadow-lg ring-4 ring-red-300',
                    texto: 'LLAMANDO',
                    icono: '🔔'
                };
            case 'EN_ATENCION':
                return {
                    clase: 'bg-green-500 text-white shadow-lg',
                    texto: 'EN ATENCIÓN',
                    icono: '👥'
                };
            case 'PENDIENTE':
                return {
                    clase: 'bg-blue-600 text-white shadow-md',
                    texto: 'PENDIENTE',
                    icono: '⏳'
                };
            default:
                return {
                    clase: 'bg-gray-500 text-white',
                    texto: 'DESCONOCIDO',
                    icono: '❓'
                };
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-blue-900 to-slate-900 flex items-center justify-center text-white">
                <div className="text-center">
                    <div className="relative">
                        <div className="animate-spin rounded-full h-20 w-20 border-4 border-blue-400 border-t-transparent mx-auto mb-6"></div>
                        <Business className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-2xl" />
                    </div>
                    <h2 className="text-2xl font-bold mb-2">Inicializando Sistema de Turnos</h2>
                    <p className="text-blue-200">Cargando configuración y mensajes...</p>
                    <div className="mt-4 flex items-center justify-center space-x-2 text-sm text-blue-300">
                        <Wifi className="animate-pulse" />
                        <span>Conectando con servidor</span>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className={`min-h-screen text-white ${obtenerClasesTema()} ${configuracion.animacionesActivas ? 'transition-all duration-1000' : ''}`}>
            {/* Audio para notificaciones */}
            <audio ref={audioRef} preload="auto">
                <source src="/sounds/turno-llamado.mp3" type="audio/mpeg" />
                <source src="/sounds/turno-llamado.wav" type="audio/wav" />
            </audio>

            {/* Header Profesional */}
            <header className="bg-black bg-opacity-30 backdrop-blur-sm border-b border-white border-opacity-20">
                <div className="max-w-7xl mx-auto px-6 py-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                            {configuracion.mostrarLogo && (
                                <div className="flex items-center space-x-3">
                                    <div className="h-16 w-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center backdrop-blur-sm">
                                        <Business className="text-3xl text-white" />
                                    </div>
                                    <div>
                                        <h1 className="text-2xl font-bold tracking-wide">
                                            {configuracion.textoEncabezado}
                                        </h1>
                                        <p className="text-sm opacity-90">Portal de Atención Ciudadana</p>
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="flex items-center space-x-6">
                            {/* Estado de conexión */}
                            <div className="flex items-center space-x-2 text-sm">
                                <div className={`w-2 h-2 rounded-full animate-pulse ${conexionEstado === 'conectado' ? 'bg-green-400' : 'bg-red-400'}`}></div>
                                <span>{conexionEstado === 'conectado' ? 'EN LÍNEA' : 'DESCONECTADO'}</span>
                            </div>

                            {/* Control de sonido */}
                            <button
                                onClick={() => setSonidoHabilitado(!sonidoHabilitado)}
                                disabled={!configuracion.sonidoActivo}
                                className="flex items-center space-x-2 bg-white bg-opacity-20 px-3 py-2 rounded-lg hover:bg-opacity-30 transition-all backdrop-blur-sm"
                            >
                                {sonidoHabilitado && configuracion.sonidoActivo ? <VolumeUp /> : <VolumeOff />}
                                <span className="text-sm">
                                    {sonidoHabilitado && configuracion.sonidoActivo ? 'SONIDO' : 'SILENCIO'}
                                </span>
                            </button>

                            {/* Hora y fecha */}
                            <div className="text-right">
                                <div className="text-xl font-mono font-bold">
                                    {horaActual.toLocaleTimeString('es-AR', {
                                        hour: '2-digit',
                                        minute: '2-digit',
                                        second: '2-digit'
                                    })}
                                </div>
                                <div className="text-xs opacity-80">
                                    {horaActual.toLocaleDateString('es-AR', {
                                        weekday: 'long',
                                        day: '2-digit',
                                        month: 'short'
                                    }).toUpperCase()}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            {/* Contenido Principal */}
            <main className="min-h-[calc(100vh-120px)]">
                {vistaActual === 'turnos' ? (
                    /* Vista de Turnos Profesional */
                    <div className="p-6">
                        <div className="max-w-7xl mx-auto">
                            {/* Turno Destacado si hay uno llamando */}
                            {turnoLlamando && (
                                <div className="mb-8">
                                    <div className="bg-red-500 bg-opacity-90 backdrop-blur-sm rounded-2xl p-8 text-center shadow-2xl ring-4 ring-red-300 animate-pulse">
                                        <div className="text-6xl mb-4">🔔</div>
                                        <div className="text-4xl font-bold mb-2">TURNO {turnoLlamando.codigo}</div>
                                        <div className="text-2xl mb-2">{turnoLlamando.sector}</div>
                                        <div className="text-xl mb-2">VENTANILLA {turnoLlamando.ventanilla}</div>
                                        <div className="text-lg opacity-90">Diríjase a la ventanilla indicada</div>
                                    </div>
                                </div>
                            )}

                            {/* Título de sección */}
                            <div className="text-center mb-8">
                                <h2 className="text-3xl font-bold mb-2">ESTADO DE TURNOS</h2>
                                <div className="w-24 h-1 bg-white bg-opacity-50 mx-auto rounded"></div>
                            </div>

                            {/* Tabla de turnos estilo banco */}
                            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl overflow-hidden shadow-2xl">
                                {/* Header de tabla */}
                                <div className="bg-black bg-opacity-30 px-6 py-4 border-b border-white border-opacity-20">
                                    <div className="grid grid-cols-6 gap-4 text-sm font-semibold uppercase tracking-wider">
                                        <div>TURNO</div>
                                        <div>SECTOR</div>
                                        <div>VENTANILLA</div>
                                        <div>ESTADO</div>
                                        <div>CIUDADANO</div>
                                        <div>TIEMPO</div>
                                    </div>
                                </div>

                                {/* Filas de turnos */}
                                <div className="divide-y divide-white divide-opacity-10">
                                    {turnos.slice(0, 8).map((turno, index) => {
                                        const estado = obtenerEstadoTurno(turno.estado);
                                        const tiempoEspera = Math.floor((Date.now() - turno.timestamp) / 60000);

                                        return (
                                            <div
                                                key={turno.id}
                                                className={`px-6 py-4 transition-all duration-500 ${turno.estado === 'LLAMANDO' ? 'bg-red-500 bg-opacity-20 transform scale-102' : index % 2 === 0 ? 'bg-white bg-opacity-5' : ''}`}
                                            >
                                                <div className="grid grid-cols-6 gap-4 items-center">
                                                    <div className="text-2xl font-bold text-blue-300">
                                                        {turno.codigo}
                                                    </div>
                                                    <div className="text-sm">
                                                        {turno.sector}
                                                    </div>
                                                    <div className="text-xl font-bold text-center">
                                                        {turno.ventanilla}
                                                    </div>
                                                    <div>
                                                        <div className={`px-3 py-1 rounded-full text-xs font-bold text-center ${estado.clase}`}>
                                                            {estado.icono} {estado.texto}
                                                        </div>
                                                    </div>
                                                    <div className="text-sm opacity-80 truncate">
                                                        {turno.ciudadano}
                                                    </div>
                                                    <div className="text-xs opacity-70">
                                                        {tiempoEspera > 0 ? `${tiempoEspera}m` : 'Ahora'}
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>

                            {/* Estadísticas rápidas */}
                            <div className="mt-8 grid grid-cols-4 gap-6">
                                <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-4 text-center">
                                    <div className="text-2xl font-bold text-blue-300">
                                        {turnos.filter(t => t.estado === 'PENDIENTE').length}
                                    </div>
                                    <div className="text-sm opacity-80">EN ESPERA</div>
                                </div>
                                <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-4 text-center">
                                    <div className="text-2xl font-bold text-green-300">
                                        {turnos.filter(t => t.estado === 'EN_ATENCION').length}
                                    </div>
                                    <div className="text-sm opacity-80">ATENDIENDO</div>
                                </div>
                                <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-4 text-center">
                                    <div className="text-2xl font-bold text-red-300">
                                        {turnos.filter(t => t.estado === 'LLAMANDO').length}
                                    </div>
                                    <div className="text-sm opacity-80">LLAMANDO</div>
                                </div>
                                <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-4 text-center">
                                    <div className="text-2xl font-bold text-yellow-300">
                                        {new Set(turnos.filter(t => t.estado !== 'PENDIENTE').map(t => t.ventanilla)).size}
                                    </div>
                                    <div className="text-sm opacity-80">VENTANILLAS ACTIVAS</div>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : (
                    /* Vista de Mensajes Multimedia */
                    <div className="flex items-center justify-center min-h-[calc(100vh-120px)] p-6">
                        <div className={`max-w-6xl w-full ${configuracion.animacionesActivas ? 'animate-fade-in' : ''}`}>
                            {mensajes[mensajeActual]?.tipo === 'VIDEO' ? (
                                /* Vista de Video */
                                <div className="text-center">
                                    <h2 className="text-4xl font-bold mb-8 text-blue-200">
                                        🎬 {mensajes[mensajeActual].titulo}
                                    </h2>
                                    <div className="bg-black bg-opacity-50 backdrop-blur-sm rounded-3xl p-8 shadow-2xl">
                                        <video
                                            ref={videoRef}
                                            className="w-full max-w-4xl h-96 object-cover rounded-2xl mx-auto shadow-2xl"
                                            autoPlay
                                            muted
                                            loop
                                            onError={(e) => console.warn('Error cargando video:', e)}
                                        >
                                            <source src={mensajes[mensajeActual].rutaArchivo} type="video/mp4" />
                                            <div className="bg-gray-800 h-96 flex items-center justify-center rounded-2xl">
                                                <span className="text-white">Video no disponible</span>
                                            </div>
                                        </video>
                                        <p className="text-2xl leading-relaxed mt-6 text-gray-200">
                                            {mensajes[mensajeActual].contenido}
                                        </p>
                                    </div>
                                </div>
                            ) : mensajes[mensajeActual]?.tipo === 'IMAGEN' ? (
                                /* Vista de Imagen */
                                <div className="text-center">
                                    <h2 className="text-4xl font-bold mb-8 text-blue-200">
                                        📢 {mensajes[mensajeActual].titulo}
                                    </h2>
                                    <div className="bg-black bg-opacity-50 backdrop-blur-sm rounded-3xl p-8 shadow-2xl">
                                        <img
                                            src={mensajes[mensajeActual].rutaArchivo}
                                            alt={mensajes[mensajeActual].titulo}
                                            className="w-full max-w-4xl h-96 object-cover rounded-2xl mx-auto shadow-2xl mb-6"
                                            onError={(e) => {
                                                console.warn('Error cargando imagen:', mensajes[mensajeActual].rutaArchivo);
                                                e.target.style.display = 'none';
                                            }}
                                        />
                                        <p className="text-2xl leading-relaxed text-gray-200">
                                            {mensajes[mensajeActual].contenido}
                                        </p>
                                    </div>
                                </div>
                            ) : (
                                /* Vista de Texto */
                                <div className="text-center">
                                    <h2 className="text-4xl font-bold mb-8 text-blue-200">
                                        📋 {mensajes[mensajeActual]?.titulo || 'Información'}
                                    </h2>
                                    <div className="bg-black bg-opacity-50 backdrop-blur-sm rounded-3xl p-12 shadow-2xl">
                                        <div className="text-3xl leading-relaxed whitespace-pre-line text-gray-100">
                                            {mensajes[mensajeActual]?.contenido || 'Contenido del mensaje'}
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </main>

            {/* Footer Informativo */}
            <footer className="bg-black bg-opacity-40 backdrop-blur-sm border-t border-white border-opacity-10 p-4">
                <div className="max-w-7xl mx-auto flex items-center justify-between text-sm opacity-80">
                    <div>
                        <span className="font-medium">Municipalidad de San Antonio</span>
                        <span className="mx-2">•</span>
                        <span>Sistema de Gestión de Turnos</span>
                    </div>
                    <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                            <Schedule className="text-xs" />
                            <span>Actualizado: {horaActual.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                            {/* <Signal className="text-xs" /> */}
                            <span>Tiempo Real</span>
                        </div>
                    </div>
                </div>
            </footer>

            {/* Estilos adicionales */}
            <style jsx>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in {
                    animation: fade-in 1s ease-out;
                }
                .scale-102 {
                    transform: scale(1.02);
                }
            `}</style>
        </div>
    );
};

export default PantallaTurnosProfesional;